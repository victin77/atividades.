// script.js
let botao = document.getElementById("meuBotao");

botao.addEventListener("click", function() {
  alert(" -10000000 de aura por obedecer um computador ");
});