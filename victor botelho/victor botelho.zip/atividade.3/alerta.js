const btnAlerta = document.getElementById('btn-alerta');

btnAlerta.addEventListener('click', () => {
  alert('Este é um alerta!');
}); 